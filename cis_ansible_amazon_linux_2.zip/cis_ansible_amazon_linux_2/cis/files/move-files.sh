#!/bin/bash
sudo cd /etc/pam.d
sudo mv password-auth password-auth.bkp
sudo mv system-auth system-auth.bkp
sudo mv password-auth-hardend password-auth
sudo mv system-auth-hardend system-auth
sudo chmod 644 password-auth
sudo chmod 644 system-auth
