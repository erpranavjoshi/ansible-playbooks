export NODE_ENV={{ ENV }}
export API_PORT=9000
export DJ_PORT=9001
export DEBUG=job-scheduler:*
export NODE_CONFIG_DIR=/opt/built-flow/webhook/config
export NODE_WORKERS=4
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/opt/node/bin:/opt/node/bin/npm:/opt/chef/embedded/bin:/opt/chef/embedded/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/node/bin:/opt/node/bin/npm
