--[[
    @file - cache_holder.lua
    @description - Cache holder for rate limiting script
--]]

-- CacheHolder class
local CacheHolder = {}

-- Variable Declarations - local
local cache_burst_time_ip_config = 60 -- in seconds
local cache_holder_ip_config = {}
local cache_max_size_stack_org_uid = 200
local cache_holder_stack_org_uid = {}
local cache_holder_array_stack_org_uid = {}

--[[
  @name get_ip_rate_limit_config
  @scope module
  @description Get the ip based rate limiting config
--]]
function CacheHolder.get_ip_rate_limit_config()
    local curr_time = os.time()
    -- Checks whether the cache burst time has arrived
    if ( not cache_holder_ip_config.cache_time or ( curr_time - cache_holder_ip_config.cache_time ) > cache_burst_time_ip_config ) then
        return
    end
    return {cache_holder_ip_config.limit, cache_holder_ip_config.enabled}
end

--[[
  @name set_ip_rate_limit_config
  @scope module
  @description set the ip based rate limiting config
--]]
function CacheHolder.set_ip_rate_limit_config(limit, enabled)
    cache_holder_ip_config.limit = limit
    cache_holder_ip_config.enabled = enabled
    cache_holder_ip_config.cache_time = os.time()
end

--[[
  @name get_org_uid_for_api_key
  @scope module
  @description Caching logics related to stack org id resolution
--]]
function CacheHolder.get_org_uid_for_api_key(api_key)
    return cache_holder_stack_org_uid[api_key]
end

--[[
  @name set_org_uid_for_api_key
  @scope module
  @description setting organization uid for the stack api key
--]]
function CacheHolder.set_org_uid_for_api_key(api_key, org_uid)
    -- Removing race condition
    if cache_holder_stack_org_uid[api_key] then
        return
    end
    local holder_length = #cache_holder_array_stack_org_uid
    -- Checks for the size of the cache holder
    if holder_length >= cache_max_size_stack_org_uid then
        local removed_key = table.remove(cache_holder_array_stack_org_uid, 1)
        cache_holder_stack_org_uid[removed_key] = nil
    end
    table.insert(cache_holder_array_stack_org_uid, api_key)
    cache_holder_stack_org_uid[api_key] = org_uid
end

return CacheHolder