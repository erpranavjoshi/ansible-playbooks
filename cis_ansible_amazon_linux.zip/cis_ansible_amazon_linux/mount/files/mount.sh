#!/bin/bash

sudo mv /home /home.old
sudo mkdir /home

sudo mv /var /var.old
sudo mkdir /var

sudo mv /var/log /varlog.old
sudo mkdir /var/log

sudo mv /var/tmp /vartmp.old
sudo mkdir /var/tmp

sudo mv /tmp /tmp.old
sudo mkdir /tmp

sudo mv /var/log/audit /varlogaudit.old
sudo mkdir /var/log/audit

sudo umount /dev/xvdf1
sudo umount /dev/xvdg1
sudo umount /dev/xvdh1
sudo umount /dev/xvdi1
sudo umount /dev/xvdj1
sudo umount /dev/xvdk1


sudo mount /dev/xvdf1 /home
sudo mount /dev/xvdg1 /var
sudo mount /dev/xvdh1 /var/log
sudo mount /dev/xvdi1 /var/tmp
sudo mount /dev/xvdj1 /tmp
sudo mount /dev/xvdk1 /var/log/audit
