#!/bin/bash
ansible-playbook restart.yml -i inventory.ini
ansible-playbook aws.yml
ansible-playbook workstation.yml -i inventory.ini
ansible-playbook restart.yml -i inventory.ini
