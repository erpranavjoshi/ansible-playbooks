#!/bin/bash
### BEGIN INIT INFO
# Provides:          nginx-chroot
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: Start Nginx Chroot...
### END INIT INFO

FULLPATH=`pwd`

export LUAJIT_LIB=/usr/local/lib/lua
export LUAJIT_INC=/usr/local/include/luajit-2.0
export LD_LIBRARY_PATH=/usr/local/lib

err_status()

{
step_1_ex_st=`echo $?`

if test $step_1_ex_st -ne 0

then 
echo "Nginx Chroot " $1 " is unsuccessful. Please contact Adminstrator"
exit

fi
}

case "$1" in
  start)
	/usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx 
	err_status
	echo "Starting Nginx with Chroot"
        ;;
  stop)
	/usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx -s stop
	err_status
	;;
  reload)
	/usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx -s reload
	err_status
	echo "Nginx with chroot reloaded"
	;;
  test|t)
        /usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx -t
        err_status
        echo "Nginx with chroot reloaded"
        ;;
  restart)
	/usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx -s stop
	/usr/sbin/chroot /opt/chroot /opt/nginx/sbin/nginx
	err_status
	echo "Nginx restarted"
	;;
      *)
        FULLPATH=/etc/init.d/$PS
        echo "Usage: $FULLPATH {start|stop|restart|reload|test|t}"
        exit 1
        ;;
esac

exit 0

