-- Variable Declarations
local redis_lua = require "redis" -- redis-lua module
local _M = {}
local Redis_Conn
--[[
    @name rate_limit_org_script
    @description does the organization rate limiting
    @KEYS
        1 - organization uid
        2 - request time 
        3 - limit key - OrgID_Get_Limit
        4 - counter key prefix - org:get:counter
    @returns
        rate_limit
        rate_limit_enabled
        org_counter
]]
local rate_limit_org_script = [[
    local org_uid = KEYS[1];
    local request_time = KEYS[2];
    local limit_key = KEYS[3];
    local counter_key = KEYS[4] .. request_time;
    local org_limits = redis.call('hmget', 'limit:' .. org_uid, limit_key, limit_key .. '_Enabled');
    local rate_limit = org_limits[1] or 0;
    local rate_limit_enabled = org_limits[2] or 0;
    local org_counter = 0;

    if tonumber(rate_limit_enabled) == 1 then
       org_counter = redis.call('hget', counter_key, org_uid) or 0;
       redis.call('hincrby', counter_key, org_uid, 1); 
       if tonumber(org_counter) == 0 then
            redis.call('expire', counter_key, 10);
       end
    end

    return {rate_limit, rate_limit_enabled, org_counter};
]]
--[[
    @name rate_limit_bulk_script 
    @description does the organization bulk rate limiting
    @KEYS
        1 - organization uid
        2 - request time 
    @returns
        rate_limit
        rate_limit_enabled
        bulk_counter
]]
local rate_limit_bulk_script = [[
    local org_uid = KEYS[1];
    local request_time = KEYS[2];
    local counter_key = "org:bulk:counter:" .. request_time;
    local org_limits = redis.call('hmget', 'limit:' .. org_uid, 'Bulk_Limit', 'Bulk_Enabled');
    local rate_limit = org_limits[1] or 0;
    local rate_limit_enabled = org_limits[2] or 0;
    local bulk_counter = 0;

    if tonumber(rate_limit_enabled) == 1 then
       bulk_counter = redis.call('hget', counter_key, org_uid) or 0;
       redis.call('hincrby', counter_key, org_uid, 1); 
       if tonumber(bulk_counter) == 0 then
            redis.call('expire', counter_key, 10);
       end
    end

    return {rate_limit, rate_limit_enabled, bulk_counter};
]]
--[[
    @name rate_limit_ip_script 
    @description does the ip based rate limiting
    @KEYS
        1 - ip
        2 - request time 
    @returns
        rate_limit_enabled
        rate_limit
        ip_counter
]]
local rate_limit_ip_script = [[
    local ip = KEYS[1];
    local request_time = KEYS[2];
    local counter_key = "ip:counter:" .. request_time;
    local ip_limits = redis.call('hmget', 'rate_limit:config:ip', 'limit', 'enabled');
    local rate_limit = ip_limits[1] or 0;
    local rate_limit_enabled = ip_limits[2] or 0;
    local ip_counter = 0;

    if tonumber(rate_limit_enabled) == 1 then
       ip_counter = redis.call('hget', counter_key, ip) or 0;
       redis.call('hincrby', counter_key, ip, 1); 
       if tonumber(ip_counter) == 0 then
            redis.call('expire', counter_key, 10);
       end
    end

    return {rate_limit_enabled, rate_limit, ip_counter};
]]

--[[
    @name connect
    @scope local
    @description Connects to the redis db
    @params variable arguments - host, port, db, password
    @returns connection table
--]]
function connect(...)
    local args = {...}
    local password = args[4]
    local db = args[3]
    -- Checks for the memoized connection
    if Redis_Conn ~= nil and Redis_Conn:ping() then
        return Redis_Conn
    else
        Redis_Conn = nil
    end
    Redis_Conn = redis_lua.connect(args[1], args[2]);
    -- Authenticates the database
    if password then
        Redis_Conn:auth(password)
    end
    -- selects the db
    if db then
        Redis_Conn:select(db)
    end
    return Redis_Conn
end

--[[
    @name close
    @scope local
    @description closes the redis db connection
    @returns nil
--]]
function close()
    if Redis_Conn == nil then
        return
    end
    Redis_Conn:quit()
end

--[[
    @name load 
    @scope module
    @description loads the lua scripts to the redis db
    @params variable arguments - host, port, db, password
    @returns 3 values - ids of loaded scripts
--]]
function _M.load(...) 
    -- Connects to the redis db
    local ok, conn = pcall(connect, unpack({...}))
    if ok then
        -- loads the rate limit scripts into redis db
        local rate_limit_org_script_id = conn:script("load", rate_limit_org_script)
        local rate_limit_bulk_script_id = conn:script("load", rate_limit_bulk_script)
        local rate_limit_ip_script_id = conn:script("load", rate_limit_ip_script)
        -- Closes the redis db connection
        pcall(close)
        Redis_Conn = nil
        rate_limit_org_script = nil
        rate_limit_bulk_script = nil
        rate_limit_ip_script = nil
        return rate_limit_org_script_id, rate_limit_bulk_script_id, rate_limit_ip_script_id
    else
        ngx.log(ngx.STDERR, "Unable to connect to redis")
        ngx.log(ngx.STDERR, conn)
        error(conn)
    end
end

return _M