-- Module dependencies - local
local redis_scripts_loader = require "redis_scripts_loader"

-- Module dependencies - global
Redis = require "resty.redis"
cache_holder = require "cache_holder"

-- Variable Declarations - global
redis_host = 'dev-server-redis.35ox5r.ng.0001.usw2.cache.amazonaws.com'
redis_port = 6378
redis_db = 0

redis_set_timeout = 1000 -- 1 second
redis_keepalive_timeout = 60000 -- 60 seconds
redis_connection_pool_size = 100 -- should be equal to (no_of_nginx_concurrent_connections/no_of_nginx_workers)

redis_structure_stack_prefix = "stack:"
redis_structure_org_prefix = "org:"
redis_structure_org_limit_prefix = "limit:"
redis_structure_rate_limit_ip = "rate_limit:config:ip"
redis_structure_rate_limit_ip_counter_prefix = "ip:counter:"
redis_structure_rate_limit_org_bulk_counter_prefix = "org:bulk:counter:"

redis_script_org_id = nil
redis_script_bulk_id = nil
redis_script_ip_id = nil

redis_counter_expiration_time = 10 -- 10 seconds

-- Variable Declarations - local
local GET_RELATED_METHODS = {"GET", "OPTIONS", "HEAD"}
local redis_scripts_load_ok = nil

-- function declarations - global
get_api_key_from_uri = nil
get_rate_limit_keys_for_method = nil
process_rate_limiting_org = nil
process_rate_limiting_ip = nil

-- function declarations - local
local add_rate_limit_exceeded_headers = nil
local add_rate_limit_headers = nil

-- Loads the redis scripts
redis_scripts_load_ok, redis_script_org_id, redis_script_bulk_id, redis_script_ip_id = pcall(redis_scripts_loader.load, redis_host, redis_port, redis_db, redis_pass)
if not redis_scripts_load_ok then
  ngx.log(ngx.STDERR, "Redis scripts not loaded")
end

--[[
  @name add_rate_limit_exceeded_headers 
  @scope local
  @description Adding the limit exceeded headers
--]]
add_rate_limit_exceeded_headers = function(limit_val, counter_val)
  local remaining_count = limit_val - counter_val - 1
  ngx.header["X-RateLimit-Limit"] = limit_val
  if remaining_count > 0 then
    ngx.header["X-RateLimit-Remaining"] = remaining_count 
  else
    ngx.header["X-RateLimit-Remaining"] = 0
  end
  ngx.header.content_type = "application/json; charset=utf-8"  
  ngx.status = 429
  ngx.say("{ \"errors\": [ { \"code\": 429, \"message\": \"Rate limit exceeded\" } ] }")
end

--[[
  @name add_rate_limit_headers 
  @scope local
  @description Adding the rate limiting headers
--]]
add_rate_limit_headers = function(limit_val, counter_val)
  local remaining_count = limit_val - counter_val 
  ngx.header["X-RateLimit-Limit"] = limit_val
  if remaining_count > 0 then
    ngx.header["X-RateLimit-Remaining"] = remaining_count
  else
    ngx.header["X-RateLimit-Remaining"] = 0
  end
end

--[[
  @name get_api_key_from_uri 
  @scope global
  @description Extracting the api key from the uri
--]]
get_api_key_from_uri = function(req_uri)
  local uriobj = {}
  local index = 1

  for token in string.gmatch(req_uri, "[^/]+") do
    uriobj[index] = token
    index = index + 1 
  end

  if uriobj[6] == "download" then
    return uriobj[3]
  end
end

--[[
  @name get_rate_limit_keys_for_method
  @scope global
  @description Gets the limit keys related to the given http method
--]]
get_rate_limit_keys_for_method = function(method)
  local keys = {}
  local _get_related_method = false
  for _, value in ipairs(GET_RELATED_METHODS) do
    if value == method then
      _get_related_method = true
      break
    end
  end
  if _get_related_method then
    keys["limit"] = "OrgID_Get_Limit"
    keys["counter"] = "org:get:counter:"
  else
    keys["limit"] = "OrgID_Limit"
    keys["counter"] = "org:counter:"
  end
  return keys
end

--[[
  @name process_rate_limiting_org 
  @scope global
  @description Process the rate limiting logic related to the organization
--]]
process_rate_limiting_org = function(org_rate_limits)
  local counter_val = tonumber(org_rate_limits[3])
  local limit_val = tonumber(org_rate_limits[1])
  local limit_enabled = tonumber(org_rate_limits[2])

  if limit_enabled == 1 then
    if counter_val < limit_val then
      counter_val = counter_val + 1
      add_rate_limit_headers(limit_val, counter_val)
    else
      add_rate_limit_exceeded_headers(limit_val, counter_val)
      return true -- returns true in case of rate limit has been exceeded
    end
  else
    error('Rate limiting is not enabled for this organization')
  end
end

--[[
  @name process_rate_limiting_bulk 
  @scope global
  @description Process the rate limiting logic related to the organization bulk api
--]]
process_rate_limiting_bulk = function(org_rate_limits)
  local counter_val = tonumber(org_rate_limits[3])
  local limit_val = tonumber(org_rate_limits[1])
  local limit_enabled = tonumber(org_rate_limits[2])

  if limit_enabled == 1 then
    if counter_val < limit_val then
      counter_val = counter_val + 1
      add_rate_limit_headers(limit_val, counter_val)
    else
      add_rate_limit_exceeded_headers(limit_val, counter_val)
      return true -- returns true in case of rate limit has been exceeded
    end
  else
    error('Bulk Rate limiting is not enabled for this organization')
  end
end

--[[
  @name process_rate_limiting_ip
  @scope global
  @description Process the rate limiting logic related to the IP address
--]]
process_rate_limiting_ip = function(addr, counter_id, counter_val, limit_val)
  counter_val = tonumber(counter_val)
  limit_val = tonumber(limit_val)

  if counter_val < limit_val then
    counter_val = counter_val + 1
    add_rate_limit_headers(limit_val, counter_val)
  else
    add_rate_limit_exceeded_headers(limit_val, counter_val)
    return true -- returns true in case of rate limit has been exceeded
  end
end
