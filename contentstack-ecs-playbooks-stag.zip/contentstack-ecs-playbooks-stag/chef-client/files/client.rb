log_level                :info   #we can change here as "debug"for more info
log_location             STDOUT
ssl_verify_mode          :verify_none
chef_server_url          "CHEF_SERVER_URL"
validation_client_name   "chef-validator"
validation_key           "/etc/chef/validation.pem"
client_key               "/etc/chef/client.pem"
cache_path 	"/etc/chef/chef-cache/"
