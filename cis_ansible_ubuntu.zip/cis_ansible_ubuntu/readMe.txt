Read this before executuning ansible playbook.
First Run playbook aws.yml to create volume and attach it to instance. Add instance id in variable file vars/vars.yml 
To run aws.yml: ansible-playbook aws.yml

1) Make neccessary changes in variables file: vars/vars.yml
2) Change target machine's IP address in file inventory.ini 
3) Change Target Machine's key file path in inventory.ini file
4) Command to run playbook for remediation: ansible-playbook workstation.yml -i inventory.ini 
