rs.initiate({ _id: 'cs-dev', members: [{_id: 0,host: "{{ host_ip }}:27017"},{_id: 1,host: "{{ host_ip }}:27018"},{_id: 2,host: "{{ host_ip }}:27019"}]})
