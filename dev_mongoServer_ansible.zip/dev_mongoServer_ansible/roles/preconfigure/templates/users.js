a="{{ value }}"
ip="{{ host_name }}"
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "rootAdmin",
    pwd: "rootAdmin",
    roles: [ { role: "root", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "dba",
    pwd: "dba",
    roles: [ { role: "backup", db: "admin" },{ role: "restore", db: "admin" },{ role: "clusterMonitor", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "userAdmin",
    pwd: "userAdmin",
    roles: [ { role: "userAdminAnyDatabase", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "clusterManager",
    pwd: "clusterManager",
    roles: [ { role: "clusterManager", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "hostManager",
    pwd: "hostManager",
    roles: [ { role: "hostManager", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/dev${a}_assignments_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_assignments_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_audit_logs_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_audit_logs_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_core_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_core_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_cs_usage_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_cs_usage_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_dj_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_dj_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_publish_logs_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_publish_logs_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_webhook_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_webhook_db` } ]
  }
)
db = connect(`${ip}:27017/dev${a}_workflow_logs`)
db.createUser(
  {
    user: "appUser",
    pwd: "appUser",
    roles: [ { role: "readWrite", db: `dev${a}_workflow_logs` } ]
  }
)
